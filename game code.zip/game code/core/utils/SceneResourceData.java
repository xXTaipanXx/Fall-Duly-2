package com.darkbrokengames.fallduly2.utils;

public class SceneResourceData {
    public String SCENE_NAME;
    public int SCENE_ID;
    public String[] TEXTURE_NAMES;
    public String[] SOUND_NAMES;
    public String[] MUSIC_NAMES;
    public String[] ATLAS_NAMES;
    public String[] MAP_NAMES;
}
