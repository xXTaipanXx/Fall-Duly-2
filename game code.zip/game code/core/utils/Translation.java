package com.darkbrokengames.fallduly2.utils;

public class Translation {
    public String LANGUAGE;
    public String H_LANGUAGE;
    public String CHOOSE_YOUR_LANGUAGE;
    public String BEST_SCORE;
    public String LIFE;
    public String WANT_TO_GO_MENU;
    public String WATCH_VIDEO_LIFE;
    public String WANT_TO_GO_OUT;
    public String SHOP;
    public String WANT_TO_BUY_SKIN;
    public String NOT_HAVE_ENOUGH_MONEY;
    public String NOT_VIDEO;
}
