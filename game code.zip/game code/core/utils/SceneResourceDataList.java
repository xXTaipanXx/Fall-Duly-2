package com.darkbrokengames.fallduly2.utils;

import com.badlogic.gdx.utils.Array;

public class SceneResourceDataList {
    public Array<SceneResourceData> SCENE_RESOURCE_DATA;
}
