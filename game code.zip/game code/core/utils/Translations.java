package com.darkbrokengames.fallduly2.utils;

import com.badlogic.gdx.utils.Array;

public class Translations {
    public Array<Translation> TRANSLATIONS;
}
