package com.darkbrokengames.fallduly2.scenes;

public interface ShopMessage {
    void showMessageBuy();
    void showMessageNoMoney();
    void setCurrentIdForBuy(int currentIdForBuy);
}
